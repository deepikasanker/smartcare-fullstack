# SmartCare Week 3 - Back-End API Development

## Project
SmartCare - AI-Based Healthcare Assistance Web Application

## Objective
This project provides RESTful APIs for managing patient information using Flask and SQLite.

## Technologies
- Python
- Flask
- SQLite
- REST API
- Pytest

## CRUD API Endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| GET | /api/patients | Get all patients |
| GET | /api/patients/<id> | Get one patient |
| POST | /api/patients | Add a patient |
| PUT | /api/patients/<id> | Update a patient |
| DELETE | /api/patients/<id> | Delete a patient |

## Installation

```bash
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
```

## Run

```bash
python app.py
```

The API runs at:
http://127.0.0.1:5000

## Example POST JSON

```json
{
    "name": "Deepika",
    "age": 18,
    "gender": "Female",
    "symptoms": "Fever and headache"
}
```

## Testing

```bash
pytest
```
