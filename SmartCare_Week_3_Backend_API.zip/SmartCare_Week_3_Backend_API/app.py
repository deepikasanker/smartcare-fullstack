from flask import Flask, request, jsonify
from database import get_db_connection, init_db

app = Flask(__name__)
init_db()

@app.route("/api/patients", methods=["GET"])
def get_patients():
    conn = get_db_connection()
    patients = conn.execute("SELECT * FROM patients").fetchall()
    conn.close()
    return jsonify([dict(patient) for patient in patients])

@app.route("/api/patients/<int:patient_id>", methods=["GET"])
def get_patient(patient_id):
    conn = get_db_connection()
    patient = conn.execute(
        "SELECT * FROM patients WHERE id = ?", (patient_id,)
    ).fetchone()
    conn.close()

    if patient is None:
        return jsonify({"error": "Patient not found"}), 404

    return jsonify(dict(patient))

@app.route("/api/patients", methods=["POST"])
def create_patient():
    data = request.get_json()

    if not data:
        return jsonify({"error": "Request body is required"}), 400

    name = data.get("name")
    age = data.get("age")
    gender = data.get("gender")
    symptoms = data.get("symptoms")

    if not all([name, age, gender, symptoms]):
        return jsonify({
            "error": "name, age, gender and symptoms are required"
        }), 400

    conn = get_db_connection()
    cursor = conn.execute(
        """INSERT INTO patients (name, age, gender, symptoms)
           VALUES (?, ?, ?, ?)""",
        (name, age, gender, symptoms)
    )
    conn.commit()
    patient_id = cursor.lastrowid
    conn.close()

    return jsonify({
        "message": "Patient added successfully",
        "id": patient_id
    }), 201

@app.route("/api/patients/<int:patient_id>", methods=["PUT"])
def update_patient(patient_id):
    data = request.get_json()

    if not data:
        return jsonify({"error": "Request body is required"}), 400

    name = data.get("name")
    age = data.get("age")
    gender = data.get("gender")
    symptoms = data.get("symptoms")

    if not all([name, age, gender, symptoms]):
        return jsonify({
            "error": "name, age, gender and symptoms are required"
        }), 400

    conn = get_db_connection()
    patient = conn.execute(
        "SELECT * FROM patients WHERE id = ?", (patient_id,)
    ).fetchone()

    if patient is None:
        conn.close()
        return jsonify({"error": "Patient not found"}), 404

    conn.execute(
        """UPDATE patients
           SET name = ?, age = ?, gender = ?, symptoms = ?
           WHERE id = ?""",
        (name, age, gender, symptoms, patient_id)
    )
    conn.commit()
    conn.close()

    return jsonify({"message": "Patient updated successfully"})

@app.route("/api/patients/<int:patient_id>", methods=["DELETE"])
def delete_patient(patient_id):
    conn = get_db_connection()
    patient = conn.execute(
        "SELECT * FROM patients WHERE id = ?", (patient_id,)
    ).fetchone()

    if patient is None:
        conn.close()
        return jsonify({"error": "Patient not found"}), 404

    conn.execute("DELETE FROM patients WHERE id = ?", (patient_id,))
    conn.commit()
    conn.close()

    return jsonify({"message": "Patient deleted successfully"})

if __name__ == "__main__":
    app.run(debug=True)
