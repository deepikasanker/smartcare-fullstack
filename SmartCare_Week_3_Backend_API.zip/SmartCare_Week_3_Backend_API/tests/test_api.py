from app import app

def test_get_patients():
    client = app.test_client()
    response = client.get("/api/patients")
    assert response.status_code == 200

def test_create_patient():
    client = app.test_client()
    response = client.post(
        "/api/patients",
        json={
            "name": "Test Patient",
            "age": 20,
            "gender": "Female",
            "symptoms": "Fever"
        }
    )
    assert response.status_code == 201
