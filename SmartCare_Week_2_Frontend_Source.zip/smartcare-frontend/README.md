# SmartCare – Front-End Week 2

A responsive front-end prototype for the SmartCare AI-Based Healthcare Assistance Web Application.

## Technologies
- HTML5
- CSS3
- JavaScript

## Views
- Landing Page: `index.html`
- User Dashboard: `dashboard.html`
- Healthcare Assistance Detail: `assistance.html`
- Profile: `profile.html`

## How to Run
1. Extract the project folder.
2. Open `index.html` in a web browser.
3. Use the navigation links to move between pages.

No backend is required for this Week 2 front-end prototype. Backend/API integration is planned for later tasks.

## Note
The healthcare assistance screen is informational/demo functionality and does not provide medical diagnosis.
